// ==UserScript==
// @name        Bypass iOS Final (VIP Pur)
// @match       *://*/*
// @run-at      document-start
// @grant       none
// ==/UserScript==

var s = document.createElement('script');
s.textContent = '(' + function () {

    const REPLACEMENTS = [
        { find: '"is_vip": false', replace: '"is_vip": true' },
        { find: '"is_vip":false', replace: '"is_vip":true' },
        { find: '"isPremium": false', replace: '"isPremium": true' },
        { find: '"isPremium":false', replace: '"isPremium":true' },
        { find: '"is_admin": false', replace: '"is_admin": true' },
        { find: '"is_admin":false', replace: '"is_admin":true' },
        { find: '"role": "user"', replace: '"role": "admin"' },
        { find: '"role":"user"', replace: '"role":"admin"' }
    ];

    function patch(text) {
        if (typeof text !== 'string') return text;
        let res = text;
        REPLACEMENTS.forEach(r => { res = res.split(r.find).join(r.replace); });
        return res;
    }

    const origFetch = window.fetch;
    window.fetch = async (...args) => {
        const response = await origFetch(...args);
        // On ne patche que si c'est du JSON ou du texte pour éviter de casser les flux vidéo
        const contentType = response.headers.get("content-type");
        if (contentType && (contentType.includes("json") || contentType.includes("text"))) {
            try {
                const text = await response.text();
                const patchedText = patch(text);
                return new Response(patchedText, {
                    status: response.status,
                    statusText: response.statusText,
                    headers: response.headers
                });
            } catch (e) {
                return response;
            }
        }
        return response;
    };

    const origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function () {
        const xhr = this;
        const origSend = xhr.send;
        xhr.send = function () {
            xhr.addEventListener('load', function () {
                if (!xhr._patched) {
                    try {
                        const patchedText = patch(xhr.responseText);
                        Object.defineProperty(xhr, 'responseText', { get: () => patchedText, configurable: true });
                        Object.defineProperty(xhr, 'response', { get: () => patchedText, configurable: true });
                        xhr._patched = true;
                    } catch (e) {}
                }
            });
            return origSend.apply(xhr, arguments);
        };
        return origOpen.apply(xhr, arguments);
    };

    console.log('%c[Bypass VIP] Mode Pur Activé ✅', 'color: #00ff00; font-weight: bold;');

}.toString() + ')();';

document.documentElement.appendChild(s);
s.remove();