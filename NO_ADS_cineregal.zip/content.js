
var s = document.createElement('script');
s.textContent = '(' + function () {

    function patchResponse(response) {
        if (!response) return response;

        if (typeof response === 'string') {
            response = response.split('isPremium":false').join('isPremium":true')
                .split('isAdmin":false').join('isAdmin":true')
                .split('"isPremium": false').join('"isPremium": true')
                .split('"isAdmin": false').join('"isAdmin": true');
        }

        return response;
    }

    var originalFetch = window.fetch;
    window.fetch = async function () {
        var res = await originalFetch.apply(this, arguments);
        try {
            var clone = res.clone();
            var text = await clone.text();
            var patched = patchResponse(text);
            return new Response(patched, {
                status: res.status,
                statusText: res.statusText,
                headers: res.headers
            });
        } catch (e) {
            return res;
        }
    };

    var originalOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function () {
        var xhr = this;
        var originalSend = xhr.send;
        xhr.send = function () {
            xhr.addEventListener('load', function () {
                if (!xhr._modifiedResponse) {
                    try {
                        var originalText = xhr.responseText;
                        var patched = patchResponse(originalText);
                        Object.defineProperty(xhr, 'responseText', {
                            get: function () { return patched; },
                            configurable: true
                        });
                        Object.defineProperty(xhr, 'response', {
                            get: function () { return patched; },
                            configurable: true
                        });
                        xhr._modifiedResponse = true;
                    } catch (e) { }
                }
            });
            return originalSend.apply(xhr, arguments);
        };
        return originalOpen.apply(xhr, arguments);
    };

    window.adsbygoogle = {
        loaded: true,
        push: function () { }
    };

    var style = document.createElement('style');
    style.innerHTML = '\
        /* Cache la modale noire de l\'Anti-Adblock (Sélecteurs d\'attributs) */\
        div[class*="z-[99998]"], div[class*="z-[99999]"] {\
            display: none !important; opacity: 0 !important; visibility: hidden !important; pointer-events: none !important;\
        }\
        /* La classe spécifique d\'Anti-Adblock sur CineRegal */\
        div[class*="jsx-d8c3dd6b902c718e"][class*="z-10"][class*="p-7"] {\
            display: none !important; opacity: 0 !important; visibility: hidden !important; pointer-events: none !important;\
        }\
        body { pointer-events: auto !important; overflow: auto !important; }\
    ';
    document.documentElement.appendChild(style);

    setInterval(function () {
        if (document.body) {
            document.body.style.pointerEvents = 'auto';
            document.body.style.overflow = 'auto';
        }

        var divs = document.querySelectorAll('div');
        for (var i = 0; i < divs.length; i++) {
            var el = divs[i];
            var txt = el.textContent || '';

            if (txt.indexOf('Bloqueur de publicités détecté') !== -1 && el.children.length === 0) {
                var current = el;
                for (var j = 0; j < 4; j++) {
                    if (current && current.tagName !== 'BODY') {
                        current.style.display = 'none';
                        current = current.parentElement;
                    }
                }
            }
        }
    }, 500);

}.toString() + ')();';

document.documentElement.appendChild(s);
s.remove();
