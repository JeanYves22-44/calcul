(() => {
    'use strict';

    // Skip only the client-side advertising count. Keep the real Turnstile
    // verification and confirmPlaybackGateAction: the server supplies the source.
    const patchedContainers = new WeakSet();
    const patchedFactories = new WeakMap();

    function patchFactory(factory) {
        if (patchedFactories.has(factory)) return patchedFactories.get(factory);
        const source = Function.prototype.toString.call(factory);
        if (!source.includes('"AdGate"') || !source.includes('ads_count')) return factory;

        function wrappedFactory(context, ...args) {
            const wrappedContext = new Proxy(context, {
                get(target, property, receiver) {
                    if (property !== 's') return Reflect.get(target, property, receiver);
                    return function (exports, ...exportArgs) {
                        if (!Array.isArray(exports)) {
                            return Reflect.apply(target.s, target, [exports, ...exportArgs]);
                        }
                        const replacements = exports.slice();
                        for (let i = 0; i < replacements.length - 2; i++) {
                            if (replacements[i] !== 'AdGate' || replacements[i + 1] !== 0 ||
                                typeof replacements[i + 2] !== 'function') continue;
                            const OriginalAdGate = replacements[i + 2];
                            replacements[i + 2] = function AdGateWithoutAds(props) {
                                if (!props?.settings || !Number.isFinite(props.settings.ads_count)) {
                                    return OriginalAdGate(props);
                                }
                                return OriginalAdGate({
                                    ...props,
                                    settings: { ...props.settings, ads_count: 0 }
                                });
                            };
                        }
                        return Reflect.apply(target.s, target, [replacements, ...exportArgs]);
                    };
                }
            });
            return Reflect.apply(factory, this, [wrappedContext, ...args]);
        }
        patchedFactories.set(factory, wrappedFactory);
        patchedFactories.set(wrappedFactory, wrappedFactory);
        return wrappedFactory;
    }

    function patchChunk(chunk) {
        if (!Array.isArray(chunk)) return chunk;
        return chunk.map((value, index) => index > 0 && typeof value === 'function'
            ? patchFactory(value) : value);
    }

    function patchContainer(container) {
        if (!container || typeof container.push !== 'function' || patchedContainers.has(container)) return container;
        patchedContainers.add(container);
        if (Array.isArray(container)) {
            for (let i = 0; i < container.length; i++) container[i] = patchChunk(container[i]);
        }
        const originalPush = container.push;
        container.push = function (...chunks) {
            return Reflect.apply(originalPush, this, chunks.map(patchChunk));
        };
        return container;
    }

    let runtime = patchContainer(globalThis.TURBOPACK || []);
    Object.defineProperty(globalThis, 'TURBOPACK', {
        configurable: true,
        enumerable: true,
        get() { return runtime; },
        // Turbopack replaces its initial array with { push: registerChunk }.
        set(value) { runtime = patchContainer(value); }
    });
})();
