'use strict';

// MAIN-world dynamic scripts are supported since Chromium 102. The manifest
// world field used by the original package requires Chromium 111.
async function registerPlayer() {
    const script = {
        id: 'cineregal-player',
        matches: ['*://cineregal.work/*', '*://*.cineregal.work/*'],
        js: ['player.js'],
        runAt: 'document_start',
        world: 'MAIN',
        persistAcrossSessions: true
    };
    const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [script.id] });
    if (existing.length) {
        await chrome.scripting.updateContentScripts([script]);
    } else {
        await chrome.scripting.registerContentScripts([script]);
    }
}

registerPlayer().catch(error => console.error('CineRegal: enregistrement du lecteur impossible', error));
