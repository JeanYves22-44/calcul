(() => {
    'use strict';
    // Preserve the player's responses, storage and actual account permissions.
    const selector = [
        'ins.adsbygoogle',
        '[data-ad-client][data-ad-slot]',
        'iframe[src*="//googleads.g.doubleclick.net/"]',
        'iframe[src*="//tpc.googlesyndication.com/"]'
    ].join(',');
    const style = document.createElement('style');
    style.textContent = `${selector} { display: none !important; }`;
    function mountStyle() {
        const root = document.head || document.documentElement;
        if (root && !style.isConnected) root.appendChild(style);
        // Continue only after the site's real security verification succeeds.
        if (!location.pathname.startsWith('/lecture/')) return;
        const complete = Array.from(document.querySelectorAll('h2'))
            .find(el => el.textContent.trim() === "C'est tout bon !");
        if (!complete) return;
        const button = Array.from(document.querySelectorAll('button')).find(el =>
            el.textContent.trim() === 'Accéder au contenu' && !el.disabled);
        if (button && !completedButtons.has(button)) {
            completedButtons.add(button);
            button.click();
        }
    }
    const completedButtons = new WeakSet();
    mountStyle();
    // document_start can precede the creation of <html>.
    const observer = new MutationObserver(mountStyle);
    observer.observe(document, { childList: true, subtree: true, attributes: true, attributeFilter: ['disabled'] });
})();
